#ifndef TESTMAP_H
#define TESTMAP_H

#define TESTMAP_WIDTH  (512)
#define TESTMAP_HEIGHT (32)
#define testMapMapLen (32768)

extern const unsigned short testMapMap[16384];

#endif
