#ifndef LOSE_H
#define LOSE_H

#define LOSE_WIDTH  (32)
#define LOSE_HEIGHT (32)
#define loseMapLen (2048)

extern const unsigned short loseMap[1024];

#endif
