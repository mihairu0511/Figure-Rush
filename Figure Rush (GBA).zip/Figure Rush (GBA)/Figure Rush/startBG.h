#ifndef STARTBG_H
#define STARTBG_H

#define STARTBG_WIDTH  (32)
#define STARTBG_HEIGHT (32)
#define startBGMapLen (2048)

extern const unsigned short startBGMap[1024];

#endif
