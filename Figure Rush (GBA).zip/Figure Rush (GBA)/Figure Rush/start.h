#ifndef START_H
#define START_H

#define START_WIDTH  (32)
#define START_HEIGHT (32)
#define startMapLen (2048)

extern const unsigned short startMap[1024];

#endif
