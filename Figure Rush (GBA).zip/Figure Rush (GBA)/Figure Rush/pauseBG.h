#ifndef PAUSEBG_H
#define PAUSEBG_H

#define PAUSEBG_WIDTH  (32)
#define PAUSEBG_HEIGHT (32)
#define pauseBGMapLen (2048)

extern const unsigned short pauseBGMap[1024];

#endif
