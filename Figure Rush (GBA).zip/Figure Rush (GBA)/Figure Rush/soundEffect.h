// soundEffect sound made by wav2c

extern const unsigned int soundEffect_sampleRate;
extern const unsigned int soundEffect_length;
extern const signed char soundEffect_data[];
