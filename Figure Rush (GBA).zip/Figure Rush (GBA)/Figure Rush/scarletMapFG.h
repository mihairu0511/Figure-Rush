#ifndef SCARLETMAPFG_H
#define SCARLETMAPFG_H

#define SCARLETMAPFG_WIDTH  (512)
#define SCARLETMAPFG_HEIGHT (32)
#define scarletMapFGMapLen (32768)

extern const unsigned short scarletMapFGMap[16384];

#endif
