#ifndef STARTFG_H
#define STARTFG_H

#define STARTFG_WIDTH  (32)
#define STARTFG_HEIGHT (32)
#define startFGMapLen (2048)

extern const unsigned short startFGMap[1024];

#endif
