#ifndef STARTTEXT_H
#define STARTTEXT_H

#define STARTTEXT_WIDTH  (32)
#define STARTTEXT_HEIGHT (32)
#define startTextMapLen (2048)

extern const unsigned short startTextMap[1024];

#endif
