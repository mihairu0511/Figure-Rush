// menusong sound made by wav2c

extern const unsigned int menusong_sampleRate;
extern const unsigned int menusong_length;
extern const signed char menusong_data[];
