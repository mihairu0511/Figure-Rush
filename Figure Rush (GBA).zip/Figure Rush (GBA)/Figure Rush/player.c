#include "gba.h"
#include "mode0.h"
#include "sprites.h"
#include "print.h"
#include "spritesheet.h"
#include "player.h"
#include "collisionmap.h"
#include "orbs.h"

void initPlayer() {
    player.x = 0;
    player.dx = 2;

    player.y = SHIFTUP(120);
    player.dy = SHIFTUP(0);

    player.width = 8;
    player.height = 8;
    
    player.onAir = 0;
    player.jumpForce = -1200;
    player.jumpCount = 0;
    player.jumping = 0;
    player.gravity = 3;

    player.oamIndex = 0;
}

void updatePlayer() {

    if (BUTTON_PRESSED(BUTTON_B) && cheat == 0) {
        cheat = 1;
    } else if (BUTTON_PRESSED(BUTTON_B) && cheat == 1) {
        cheat = 0;
    }
    
    int leftX = player.x;
    int rightX = player.x + player.width - 1;
    int topY = SHIFTDOWN(player.y);
    int bottomY = SHIFTDOWN(player.y) + player.height - 1;

    //NEEDLE COLLISION
    if (colorAt(leftX, bottomY + 1) == 2 | colorAt(rightX, bottomY + 1) == 2
        | colorAt(rightX + 1, topY) == 2 | colorAt(rightX + 1, bottomY) == 2) {
        lose = 1;
        mgba_printf("needle collision");
    }

    player.x += player.dx;

    if (GRAVITY > 0) {
        player.onAir = colorAt(leftX, bottomY + 1) && colorAt(rightX, bottomY + 1);
    } else {
        player.onAir = colorAt(leftX, topY + 1) && colorAt(rightX, topY + 1);
    }
    

    if (!player.onAir) {
        // mgba_printf("grounded");
        player.dy = 0;

        if (cheat == 1) {
            player.jumpCount = 2;
        } else {
            player.jumpCount = 1;
        }

    } else {
        // mgba_printf("not grounded");
        player.dy = CEILING(player.dy + GRAVITY, TERMINALVELOCITY);

        for (int i = SHIFTDOWN(player.y) + player.height; i < (SHIFTDOWN(player.y) + player.height +SHIFTDOWN(player.dy) + 1); ++i) {
            // mgba_printf("coloat: %d", !colorAt(leftX, i) && !colorAt(rightX, i));
            if (!colorAt(leftX, i) && !colorAt(rightX, i)) {
                if (GRAVITY > 0) {
                    player.dy = SHIFTUP(i - bottomY - 1);
                } else {
                    player.dy = SHIFTUP(i + topY + 1);
                }
                break;
            }
        }
    }

    int jumpCondition = player.jumpCount > 0;

    if (cheat == 0) {
        if (BUTTON_HELD(BUTTON_A) && jumpCondition) {
            // Set y velocity to initial velocity for jump
            player.dy = player.jumpForce;
            // Burn a jump
            --player.jumpCount;
        }
    } else {
        if (BUTTON_PRESSED(BUTTON_A) && jumpCondition) {
            // Set y velocity to initial velocity for jump
            player.dy = player.jumpForce;
            // Burn a jump
            --player.jumpCount;
        }
    }

    for (int i = 0; i < YELLOW_ORB_COUNT; ++i) {
        if (BUTTON_PRESSED(BUTTON_A) && collision(player.x, SHIFTDOWN(player.y), player.width, player.height, yellowOrb[i].x, yellowOrb[i].y, yellowOrb[i].width, yellowOrb[i].height)) {
            mgba_printf("collided");
            player.dy = player.jumpForce;
            --player.jumpCount;
        }
    }

    for (int i = 0; i < YELLOW_PLATFORM_COUNT; ++i) {
        if (collision(player.x, SHIFTDOWN(player.y), player.width, player.height, yellowPlatform[i].x, yellowPlatform[i].y, yellowPlatform[i].width, yellowPlatform[i].height)) {
            player.dy = -2000;
            --player.jumpCount;
        }
    }

    for (int i = 0; i < BLUE_ORB_COUNT; ++i) {
        if (BUTTON_PRESSED(BUTTON_A) && collision(player.x, SHIFTDOWN(player.y), player.width, player.height, blueOrb[i].x, blueOrb[i].y, blueOrb[i].width, blueOrb[i].height)) {
            mgba_printf("collision");
            
            GRAVITY *= -1;
            player.jumpForce *= -1;
        }
    }

    player.y += player.dy;
}

void drawPlayer() {
    shadowOAM[player.oamIndex].attr0 = ATTR0_REGULAR |ATTR0_SQUARE| ATTR0_Y(SHIFTDOWN(player.y) - vOff);

    if (GRAVITY > 0) {
        shadowOAM[player.oamIndex].attr1 = ATTR1_TINY | ATTR1_X(player.x - hOff);
    } else {
        shadowOAM[player.oamIndex].attr1 = ATTR1_VFLIP | ATTR1_TINY | ATTR1_X(player.x - hOff);
    }

    if (cheat == 0) {
        shadowOAM[player.oamIndex].attr2 = ATTR2_PALROW(0) | (ATTR2_TILEID(0, 0));
    } else {
        shadowOAM[player.oamIndex].attr2 = ATTR2_PALROW(0) | (ATTR2_TILEID(0, 1));
    }
}

inline unsigned char colorAt(int x, int y){
    return ((unsigned char *) collisionmapBitmap) [OFFSET(x, y, 4096)];
}

int getDigit(int number, int position) {

    int divisor = pow(10, position - 1);
    return (number / divisor) % 10;
}

void updatePoint() {
    int oneth = getDigit(attempt, 1);
    int tenth = getDigit(attempt, 2);
    int hundredth = getDigit(attempt, 3);

    switch (oneth) {
        case 0:
            SCREENBLOCK[0].tilemap[OFFSET(16, 11, 32)] = 75;
            SCREENBLOCK[0].tilemap[OFFSET(17, 11, 32)] = 76;
            SCREENBLOCK[0].tilemap[OFFSET(16, 12, 32)] = 107;
            SCREENBLOCK[0].tilemap[OFFSET(17, 12, 32)] = 108;
            break;
        case 1:
            SCREENBLOCK[0].tilemap[OFFSET(16, 11, 32)] = 141;
            SCREENBLOCK[0].tilemap[OFFSET(17, 11, 32)] = 142;
            SCREENBLOCK[0].tilemap[OFFSET(16, 12, 32)] = 173;
            SCREENBLOCK[0].tilemap[OFFSET(17, 12, 32)] = 174;
            break;
        case 2:
            SCREENBLOCK[0].tilemap[OFFSET(16, 11, 32)] = 143;
            SCREENBLOCK[0].tilemap[OFFSET(17, 11, 32)] = 144;
            SCREENBLOCK[0].tilemap[OFFSET(16, 12, 32)] = 175;
            SCREENBLOCK[0].tilemap[OFFSET(17, 12, 32)] = 176;
            break;
        case 3:
            SCREENBLOCK[0].tilemap[OFFSET(16, 11, 32)] = 145;
            SCREENBLOCK[0].tilemap[OFFSET(17, 11, 32)] = 146;
            SCREENBLOCK[0].tilemap[OFFSET(16, 12, 32)] = 177;
            SCREENBLOCK[0].tilemap[OFFSET(17, 12, 32)] = 178;
            break;
        case 4:
            SCREENBLOCK[0].tilemap[OFFSET(16, 11, 32)] = 147;
            SCREENBLOCK[0].tilemap[OFFSET(17, 11, 32)] = 148;
            SCREENBLOCK[0].tilemap[OFFSET(16, 12, 32)] = 179;
            SCREENBLOCK[0].tilemap[OFFSET(17, 12, 32)] = 180;
            break;
        case 5:
            SCREENBLOCK[0].tilemap[OFFSET(16, 11, 32)] = 149;
            SCREENBLOCK[0].tilemap[OFFSET(17, 11, 32)] = 150;
            SCREENBLOCK[0].tilemap[OFFSET(16, 12, 32)] = 181;
            SCREENBLOCK[0].tilemap[OFFSET(17, 12, 32)] = 182;
            break;
        case 6:
            SCREENBLOCK[0].tilemap[OFFSET(16, 11, 32)] = 151;
            SCREENBLOCK[0].tilemap[OFFSET(17, 11, 32)] = 152;
            SCREENBLOCK[0].tilemap[OFFSET(16, 12, 32)] = 183;
            SCREENBLOCK[0].tilemap[OFFSET(17, 12, 32)] = 184;
            break;
        case 7:
            SCREENBLOCK[0].tilemap[OFFSET(16, 11, 32)] = 153;
            SCREENBLOCK[0].tilemap[OFFSET(17, 11, 32)] = 154;
            SCREENBLOCK[0].tilemap[OFFSET(16, 12, 32)] = 185;
            SCREENBLOCK[0].tilemap[OFFSET(17, 12, 32)] = 186;
            break;
        case 8:
            SCREENBLOCK[0].tilemap[OFFSET(16, 11, 32)] = 155;
            SCREENBLOCK[0].tilemap[OFFSET(17, 11, 32)] = 156;
            SCREENBLOCK[0].tilemap[OFFSET(16, 12, 32)] = 187;
            SCREENBLOCK[0].tilemap[OFFSET(17, 12, 32)] = 188;
            break;
        case 9:
            SCREENBLOCK[0].tilemap[OFFSET(16, 11, 32)] = 157;
            SCREENBLOCK[0].tilemap[OFFSET(17, 11, 32)] = 158;
            SCREENBLOCK[0].tilemap[OFFSET(16, 12, 32)] = 189;
            SCREENBLOCK[0].tilemap[OFFSET(17, 12, 32)] = 190;
            break;
    }

    switch (tenth) {
        case 0:
            SCREENBLOCK[0].tilemap[OFFSET(14, 11, 32)] = 75;
            SCREENBLOCK[0].tilemap[OFFSET(15, 11, 32)] = 76;
            SCREENBLOCK[0].tilemap[OFFSET(14, 12, 32)] = 107;
            SCREENBLOCK[0].tilemap[OFFSET(15, 12, 32)] = 108;
            break;
        case 1:
            SCREENBLOCK[0].tilemap[OFFSET(14, 11, 32)] = 141;
            SCREENBLOCK[0].tilemap[OFFSET(15, 11, 32)] = 142;
            SCREENBLOCK[0].tilemap[OFFSET(14, 12, 32)] = 173;
            SCREENBLOCK[0].tilemap[OFFSET(15, 12, 32)] = 174;
            break;
        case 2:
            SCREENBLOCK[0].tilemap[OFFSET(14, 11, 32)] = 143;
            SCREENBLOCK[0].tilemap[OFFSET(15, 11, 32)] = 144;
            SCREENBLOCK[0].tilemap[OFFSET(14, 12, 32)] = 175;
            SCREENBLOCK[0].tilemap[OFFSET(15, 12, 32)] = 176;
            break;
        case 3:
            SCREENBLOCK[0].tilemap[OFFSET(14, 11, 32)] = 145;
            SCREENBLOCK[0].tilemap[OFFSET(15, 11, 32)] = 146;
            SCREENBLOCK[0].tilemap[OFFSET(14, 12, 32)] = 177;
            SCREENBLOCK[0].tilemap[OFFSET(15, 12, 32)] = 178;
            break;
        case 4:
            SCREENBLOCK[0].tilemap[OFFSET(14, 11, 32)] = 147;
            SCREENBLOCK[0].tilemap[OFFSET(15, 11, 32)] = 148;
            SCREENBLOCK[0].tilemap[OFFSET(14, 12, 32)] = 179;
            SCREENBLOCK[0].tilemap[OFFSET(15, 12, 32)] = 180;
            break;
        case 5:
            SCREENBLOCK[0].tilemap[OFFSET(14, 11, 32)] = 149;
            SCREENBLOCK[0].tilemap[OFFSET(15, 11, 32)] = 150;
            SCREENBLOCK[0].tilemap[OFFSET(14, 12, 32)] = 181;
            SCREENBLOCK[0].tilemap[OFFSET(15, 12, 32)] = 182;
            break;
        case 6:
            SCREENBLOCK[0].tilemap[OFFSET(14, 11, 32)] = 151;
            SCREENBLOCK[0].tilemap[OFFSET(15, 11, 32)] = 152;
            SCREENBLOCK[0].tilemap[OFFSET(14, 12, 32)] = 183;
            SCREENBLOCK[0].tilemap[OFFSET(15, 12, 32)] = 184;
            break;
        case 7:
            SCREENBLOCK[0].tilemap[OFFSET(14, 11, 32)] = 153;
            SCREENBLOCK[0].tilemap[OFFSET(15, 11, 32)] = 154;
            SCREENBLOCK[0].tilemap[OFFSET(14, 12, 32)] = 185;
            SCREENBLOCK[0].tilemap[OFFSET(15, 12, 32)] = 186;
            break;
        case 8:
            SCREENBLOCK[0].tilemap[OFFSET(14, 11, 32)] = 155;
            SCREENBLOCK[0].tilemap[OFFSET(15, 11, 32)] = 156;
            SCREENBLOCK[0].tilemap[OFFSET(14, 12, 32)] = 187;
            SCREENBLOCK[0].tilemap[OFFSET(15, 12, 32)] = 188;
            break;
        case 9:
            SCREENBLOCK[0].tilemap[OFFSET(14, 11, 32)] = 157;
            SCREENBLOCK[0].tilemap[OFFSET(15, 11, 32)] = 158;
            SCREENBLOCK[0].tilemap[OFFSET(14, 12, 32)] = 189;
            SCREENBLOCK[0].tilemap[OFFSET(15, 12, 32)] = 190;
            break;
    }

    switch (hundredth) {
        case 0:
            SCREENBLOCK[0].tilemap[OFFSET(12, 11, 32)] = 75;
            SCREENBLOCK[0].tilemap[OFFSET(13, 11, 32)] = 76;
            SCREENBLOCK[0].tilemap[OFFSET(12, 12, 32)] = 107;
            SCREENBLOCK[0].tilemap[OFFSET(13, 12, 32)] = 108;
            break;
        case 1:
            SCREENBLOCK[0].tilemap[OFFSET(12, 11, 32)] = 141;
            SCREENBLOCK[0].tilemap[OFFSET(13, 11, 32)] = 142;
            SCREENBLOCK[0].tilemap[OFFSET(12, 12, 32)] = 173;
            SCREENBLOCK[0].tilemap[OFFSET(13, 12, 32)] = 174;
            break;
        case 2:
            SCREENBLOCK[0].tilemap[OFFSET(12, 11, 32)] = 143;
            SCREENBLOCK[0].tilemap[OFFSET(13, 11, 32)] = 144;
            SCREENBLOCK[0].tilemap[OFFSET(12, 12, 32)] = 175;
            SCREENBLOCK[0].tilemap[OFFSET(13, 12, 32)] = 176;
            break;
        case 3:
            SCREENBLOCK[0].tilemap[OFFSET(12, 11, 32)] = 145;
            SCREENBLOCK[0].tilemap[OFFSET(13, 11, 32)] = 146;
            SCREENBLOCK[0].tilemap[OFFSET(12, 12, 32)] = 177;
            SCREENBLOCK[0].tilemap[OFFSET(13, 12, 32)] = 178;
            break;
        case 4:
            SCREENBLOCK[0].tilemap[OFFSET(12, 11, 32)] = 147;
            SCREENBLOCK[0].tilemap[OFFSET(13, 11, 32)] = 148;
            SCREENBLOCK[0].tilemap[OFFSET(12, 12, 32)] = 179;
            SCREENBLOCK[0].tilemap[OFFSET(13, 12, 32)] = 180;
            break;
        case 5:
            SCREENBLOCK[0].tilemap[OFFSET(12, 11, 32)] = 149;
            SCREENBLOCK[0].tilemap[OFFSET(13, 11, 32)] = 150;
            SCREENBLOCK[0].tilemap[OFFSET(12, 12, 32)] = 181;
            SCREENBLOCK[0].tilemap[OFFSET(13, 12, 32)] = 182;
            break;
        case 6:
            SCREENBLOCK[0].tilemap[OFFSET(12, 11, 32)] = 151;
            SCREENBLOCK[0].tilemap[OFFSET(13, 11, 32)] = 152;
            SCREENBLOCK[0].tilemap[OFFSET(12, 12, 32)] = 183;
            SCREENBLOCK[0].tilemap[OFFSET(13, 12, 32)] = 184;
            break;
        case 7:
            SCREENBLOCK[0].tilemap[OFFSET(12, 11, 32)] = 153;
            SCREENBLOCK[0].tilemap[OFFSET(13, 11, 32)] = 154;
            SCREENBLOCK[0].tilemap[OFFSET(12, 12, 32)] = 185;
            SCREENBLOCK[0].tilemap[OFFSET(13, 12, 32)] = 186;
            break;
        case 8:
            SCREENBLOCK[0].tilemap[OFFSET(12, 11, 32)] = 155;
            SCREENBLOCK[0].tilemap[OFFSET(13, 11, 32)] = 156;
            SCREENBLOCK[0].tilemap[OFFSET(12, 12, 32)] = 187;
            SCREENBLOCK[0].tilemap[OFFSET(13, 12, 32)] = 188;
            break;
        case 9:
            SCREENBLOCK[0].tilemap[OFFSET(12, 11, 32)] = 157;
            SCREENBLOCK[0].tilemap[OFFSET(13, 11, 32)] = 158;
            SCREENBLOCK[0].tilemap[OFFSET(12, 12, 32)] = 189;
            SCREENBLOCK[0].tilemap[OFFSET(13, 12, 32)] = 190;
            break;
    }
}