#ifndef PLAYER_H
#define PLAYER_H

int needleCollision;
int wallCollision;
int lose;
int attempt;

typedef struct {
    int x;
    int dx;

    int y;
    int dy;

    int width;
    int height;

    int onAir;
    int jumpForce;
    int jumpCount;
    int jumping;
    int gravity;

    int oamIndex;
} PLAYER;

PLAYER player;

void initPlayer();
void updatePlayer();
void drawPlayer();

inline unsigned char colorAt(int x, int y);

int getDigit();
void updatePoint();


#endif