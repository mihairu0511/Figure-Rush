#ifndef WIN_H
#define WIN_H

#define WIN_WIDTH  (32)
#define WIN_HEIGHT (32)
#define winMapLen (2048)

extern const unsigned short winMap[1024];

#endif
