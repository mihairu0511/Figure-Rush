// scarletMusic sound made by wav2c

extern const unsigned int scarletMusic_sampleRate;
extern const unsigned int scarletMusic_length;
extern const signed char scarletMusic_data[];
