#ifndef MANUAL_H
#define MANUAL_H

#define MANUAL_WIDTH  (32)
#define MANUAL_HEIGHT (32)
#define manualMapLen (2048)

extern const unsigned short manualMap[1024];

#endif
