#ifndef SCARTLETBG_H
#define SCARTLETBG_H

#define SCARTLETBG_WIDTH  (32)
#define SCARTLETBG_HEIGHT (32)
#define scartletBGMapLen (2048)

extern const unsigned short scartletBGMap[1024];

#endif
