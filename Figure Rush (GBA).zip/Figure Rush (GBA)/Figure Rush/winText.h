#ifndef WINTEXT_H
#define WINTEXT_H

#define WINTEXT_WIDTH  (32)
#define WINTEXT_HEIGHT (32)
#define winTextMapLen (2048)

extern const unsigned short winTextMap[1024];

#endif
