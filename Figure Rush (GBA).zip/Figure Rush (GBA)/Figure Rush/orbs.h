#ifndef ORBS_H
#define ORBS_H

typedef struct {
    int x;
    int y;
    int width;
    int height;
    int oamIndex;
    int timeUntilNextFrame;
    int currentFrame;
    int numFrames;
} YELLOW_ORB;

#define YELLOW_ORB_COUNT 2

YELLOW_ORB yellowOrb[YELLOW_ORB_COUNT];

typedef struct {
    int x;
    int y;
    int width;
    int height;
    int oamIndex;
    int timeUntilNextFrame;
    int currentFrame;
    int numFrames;
} BLUE_ORB;

#define BLUE_ORB_COUNT 2

BLUE_ORB blueOrb[BLUE_ORB_COUNT];

typedef struct {
    int x;
    int y;
    int width;
    int height;
    int oamIndex;
    int timeUntilNextFrame;
    int currentFrame;
    int numFrames;
} YELLOW_PLATFORM;

#define YELLOW_PLATFORM_COUNT 3

YELLOW_PLATFORM yellowPlatform[YELLOW_PLATFORM_COUNT];

void initOrbs();
void animateOrbs();
void updateOrbs();
void drawOrbs();

#endif