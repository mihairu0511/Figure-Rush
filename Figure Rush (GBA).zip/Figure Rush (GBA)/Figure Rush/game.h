#ifndef GAME_H
#define GAME_H

#define GAME_WIDTH  (32)
#define GAME_HEIGHT (32)
#define gameMapLen (2048)

extern const unsigned short gameMap[1024];

#endif
