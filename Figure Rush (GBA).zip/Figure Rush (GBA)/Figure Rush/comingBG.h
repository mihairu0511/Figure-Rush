#ifndef COMINGBG_H
#define COMINGBG_H

#define COMINGBG_WIDTH  (32)
#define COMINGBG_HEIGHT (32)
#define comingBGMapLen (2048)

extern const unsigned short comingBGMap[1024];

#endif
