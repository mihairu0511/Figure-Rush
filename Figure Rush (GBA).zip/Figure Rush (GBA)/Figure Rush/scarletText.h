#ifndef SCARLETTEXT_H
#define SCARLETTEXT_H

#define SCARLETTEXT_WIDTH  (32)
#define SCARLETTEXT_HEIGHT (32)
#define scarletTextMapLen (2048)

extern const unsigned short scarletTextMap[1024];

#endif
