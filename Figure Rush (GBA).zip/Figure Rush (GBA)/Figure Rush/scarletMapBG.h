#ifndef SCARLETMAPBG_H
#define SCARLETMAPBG_H

#define SCARLETMAPBG_WIDTH  (32)
#define SCARLETMAPBG_HEIGHT (32)
#define scarletMapBGMapLen (2048)

extern const unsigned short scarletMapBGMap[1024];

#endif
