//Include Necessary files
#include "gba.h"
#include "mode0.h"
#include "sprites.h"
#include "print.h"
#include "digitalSound.h"

#include "tileset.h"
#include "spritesheet.h"

#include "player.h"
#include "orbs.h"

#include "startBG.h"
#include "startFG.h"
#include "startText.h"

#include "scartletBG.h"
#include "scarletText.h"

#include "comingBG.h"
#include "comingText.h"

#include "pauseBG.h"
#include "pauseText.h"

#include "loseText.h"
#include "winText.h"

#include "scarletMapBG.h"
#include "scarletMapFG.h"

#include "manual.h"

#include "menusong.h"
#include "soundEffect.h"
#include "scarletMusic.h"
#include "winSound.h"

void initialize();

void updateMenu();
void updateGame();
void drawGame();

void goToStart();
void goToManual();
void goToSelectGame();
void goToSelectComing();
void goToGame();
void goToPause();
void goToWin();
void goToLose();

void setupInterrupts();
void interruptHandler();

unsigned short buttons;
unsigned short oldButtons;

int hOff;
int vOff;
int mapWidth;
int mapHeight;

int currentSBB;

enum STATE {START, MANUAL, SELECT_GAME, SELECT_COMING, PAUSE, GAME, WIN} state;

int main() {

    initialize();

    while(1) {

        oldButtons = buttons;
        buttons = REG_BUTTONS;

        switch(state) {
            case START:
                if (BUTTON_PRESSED(BUTTON_A)) {
                    lose = 0;
                    playSoundB(soundEffect_data, soundEffect_length, 0);
                    goToSelectGame();
                }
                if (BUTTON_PRESSED(BUTTON_SELECT)) {
                    goToManual();
                }

                updateMenu();
                waitForVBlank();

                REG_BG1HOFF = hOffBG1;
                REG_BG2HOFF = hOffBG2;

                break;
            
            case MANUAL:
                if (BUTTON_PRESSED(BUTTON_SELECT)) {
                    goToStart();
                }
                REG_BG0HOFF = 0;
                REG_BG0VOFF = 0;
                REG_BG1HOFF = 0;
                break;
            
            case SELECT_GAME:
                if (BUTTON_PRESSED(BUTTON_SELECT)) {
                    goToStart();
                }
                if (BUTTON_PRESSED(BUTTON_A)) {
                    initPlayer();
                    lose = 0;
                    playSoundB(soundEffect_data, soundEffect_length, 0);
                    initPlayer();
                    goToGame();
                }
                if (BUTTON_PRESSED(BUTTON_RIGHT)) {
                    goToSelectComing();
                    playSoundB(soundEffect_data, soundEffect_length, 0);
                }
                if (BUTTON_PRESSED(BUTTON_LEFT)) {
                    goToSelectComing();
                    playSoundB(soundEffect_data, soundEffect_length, 0);
                }
                REG_BG1HOFF = 0;
                REG_BG2HOFF = 0;
                break;

            case SELECT_COMING:
                if (BUTTON_PRESSED(BUTTON_SELECT)) {
                    goToStart();
                }
                if (BUTTON_PRESSED(BUTTON_RIGHT)) {
                    goToSelectGame();
                    playSoundB(soundEffect_data, soundEffect_length, 0);
                }
                if (BUTTON_PRESSED(BUTTON_LEFT)) {
                    goToSelectGame();
                    playSoundB(soundEffect_data, soundEffect_length, 0);
                }
                break;

            case GAME:
                if (BUTTON_PRESSED(BUTTON_SELECT)) {
                    goToPause();
                }
                if (lose == 1) {
                    initPlayer();
                    goToGame();
                    GRAVITY = 80;
                    attempt++;
                }
                if (player.x + player.width >= 4096) {
                    playSoundB(winSound_data, winSound_length, 0);
                    goToWin();
                }
                if (SHIFTDOWN(player.y) > 240) {
                    initPlayer();
                    goToGame();
                    attempt++;
                }
                updateGame();
                drawGame();
                waitForVBlank();

                REG_BG1HOFF = hOffBG1;

                REG_BG0HOFF = hOff % 256;
                REG_BG0VOFF = vOff % 256;
                REG_BG0CNT = BG_SIZE_WIDE | BG_SCREENBLOCK(currentSBB) | BG_CHARBLOCK(3);

                DMANow(3, shadowOAM, OAM, 128 * 4);
                break;

            case PAUSE:
                if (BUTTON_PRESSED(BUTTON_SELECT)) {
                    unpauseSoundA();
                    goToGame();
                }
                hideSprites();
                waitForVBlank();
                REG_BG0CNT = BG_SIZE_SMALL | BG_SCREENBLOCK(0) | BG_CHARBLOCK(3);
                REG_BG0HOFF = 0;
                REG_BG0VOFF = 0;
                REG_BG1HOFF = 0;
                DMANow(3, shadowOAM, OAM, 128 * 4);

                SCREENBLOCK[0].tilemap[OFFSET(16, 11, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(17, 11, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(16, 12, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(17, 12, 32)] = 103;

                SCREENBLOCK[0].tilemap[OFFSET(14, 11, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(15, 11, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(14, 12, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(15, 12, 32)] = 103;

                SCREENBLOCK[0].tilemap[OFFSET(12, 11, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(13, 11, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(12, 12, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(13, 12, 32)] = 103;

                break;

            case WIN:
                if (BUTTON_PRESSED(BUTTON_START)) {
                    pauseSoundA();
                    playSoundA(menusong_data, menusong_length, 1);
                    goToStart();
                }
                hideSprites();
                waitForVBlank();
                REG_BG0CNT = BG_SIZE_SMALL | BG_SCREENBLOCK(0) | BG_CHARBLOCK(3);
                REG_BG0HOFF = 0;
                REG_BG0VOFF = 0;
                REG_BG1HOFF = 0;
                DMANow(3, shadowOAM, OAM, 128 * 4);

                SCREENBLOCK[0].tilemap[OFFSET(16, 11, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(17, 11, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(16, 12, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(17, 12, 32)] = 103;

                SCREENBLOCK[0].tilemap[OFFSET(14, 11, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(15, 11, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(14, 12, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(15, 12, 32)] = 103;

                SCREENBLOCK[0].tilemap[OFFSET(12, 11, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(13, 11, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(12, 12, 32)] = 103;
                SCREENBLOCK[0].tilemap[OFFSET(13, 12, 32)] = 103;

                break;
        }
    }
    return 0;
}

void initialize() {
    mgba_open();

    GRAVITY = 80;

    initOrbs();

    setupSounds();
    setupInterrupts();

    REG_DISPCTL = MODE(0) | BG0_ENABLE | BG1_ENABLE | BG2_ENABLE | SPRITE_ENABLE;
    REG_BG0CNT = BG_SIZE_SMALL | BG_SCREENBLOCK(0) | BG_CHARBLOCK(3);
    REG_BG1CNT = BG_SIZE_SMALL | BG_SCREENBLOCK(18) | BG_CHARBLOCK(3);
    REG_BG2CNT = BG_SIZE_SMALL | BG_SCREENBLOCK(20) | BG_CHARBLOCK(3);


    hOff = 0;
    vOff = 0;
    hOffBG1 = 0;
    hOffBG2 = 0;

    mapWidth = 4096;
    mapHeight = 256;

    attempt = 0;

    DMANow(3, tilesetPal, BG_PALETTE, 256);
    DMANow(3, tilesetTiles, &CHARBLOCK[3], tilesetTilesLen / 2);

    lose = 0;
    cheat = 0;

    playSoundA(menusong_data, menusong_length, 1);

    goToStart();
}

void updateMenu() {
    hOffBG1+=2;
    hOffBG2++;
}

void updateGame() {
    updatePlayer();
    animateOrbs();
    updatePoint();

    hOffBG1++;
    hOff = CLAMP(player.x - ((180 - player.width) / 2), 0, mapWidth - SCREENWIDTH);
    vOff = CLAMP(SHIFTDOWN(player.y) - ((265 - player.height) / 2), 0, mapWidth - SCREENWIDTH);
    currentSBB = hOff / 256;
    }

void drawGame() {
    drawPlayer();
    drawOrbs();
}

void goToStart() {
    DMANow(3, startTextMap, &SCREENBLOCK[0], startTextMapLen / 2);
    DMANow(3, startFGMap, &SCREENBLOCK[18], startFGMapLen / 2);
    DMANow(3, startBGMap, &SCREENBLOCK[20], startBGMapLen / 2);

    state = START;
}

void goToManual() {
    DMANow(3, manualMap, &SCREENBLOCK[0], manualMapLen / 2);
    DMANow(3, pauseBGMap, &SCREENBLOCK[18], pauseBGMapLen / 2);

    state = MANUAL;
}

void goToSelectGame() {
    DMANow(3, scarletTextMap, &SCREENBLOCK[0], scarletTextMapLen / 2);
    DMANow(3, scartletBGMap, &SCREENBLOCK[18], scartletBGMapLen / 2);

    state = SELECT_GAME;
}

void goToSelectComing() {
    DMANow(3, comingTextMap, &SCREENBLOCK[0], comingTextMapLen / 2);
    DMANow(3, comingBGMap, &SCREENBLOCK[18], comingBGMapLen / 2);

    for (int i = 0; i < 32; ++i) {
        for (int j = 0; j < 32; ++j) {
            SCREENBLOCK[0].tilemap[OFFSET(i, j, 32)] |= TILEMAP_ENTRY_PALROW(1);
            SCREENBLOCK[18].tilemap[OFFSET(i, j, 32)] |= TILEMAP_ENTRY_PALROW(1);
        }
    }
    state = SELECT_COMING;
}

void goToGame() {

    DMANow(3, scarletMapFGMap, &SCREENBLOCK[0], scarletMapFGMapLen / 2);
    DMANow(3, scarletMapBGMap, &SCREENBLOCK[18], scarletMapBGMapLen / 2);

    DMANow(3, &spritesheetTiles, &CHARBLOCK[20], spritesheetTilesLen / 2);
    DMANow(3, &spritesheetPal, SPRITE_PALETTE, spritesheetPalLen / 2);
    hideSprites();
    waitForVBlank();
    DMANow(3, shadowOAM, OAM, 128 * 4);

    lose = 0;
    pauseSoundA();

    playSoundA(scarletMusic_data, scarletMusic_length, 0);

    state = GAME;
}

void goToPause() {
    DMANow(3, pauseTextMap, &SCREENBLOCK[0], pauseTextMapLen / 2);
    DMANow(3, pauseBGMap, &SCREENBLOCK[18], pauseBGMapLen / 2);
    pauseSoundA();
    state = PAUSE;
}

void goToWin() {
    DMANow(3, winTextMap, &SCREENBLOCK[0], winTextMapLen / 2);
    DMANow(3, pauseBGMap, &SCREENBLOCK[18], pauseBGMapLen / 2);
    state = WIN;
}

void setupInterrupts() {

	REG_IME = 0;

    REG_IE = IRQ_VBLANK;
    REG_DISPSTAT = DISPSTAT_VBLANK_IRQ;

    REG_INTERRUPT = interruptHandler;
	REG_IME = 1;
} 

void interruptHandler() {

	REG_IME = 0;

    if (REG_IF & IRQ_VBLANK) {
        if (soundA.isPlaying) {
            soundA.vBlankCount++;
            if (soundA.vBlankCount >= soundA.durationInVBlanks) {
                if (soundA.looping) {
                    playSoundA(soundA.data, soundA.dataLength, soundA.looping);
                } else {
                    soundA.isPlaying = 0;
                    REG_TM0CNT = TIMER_OFF;
                    dma[1].cnt = 0;
                }
            }
        }
        if (soundB.isPlaying) {
            soundB.vBlankCount++;
            if (soundB.vBlankCount >= soundB.durationInVBlanks) {
                if (soundB.looping) {
                    playSoundB(soundB.data, soundB.dataLength, soundB.looping);
                } else {
                    soundB.isPlaying = 0;
                    REG_TM1CNT = TIMER_OFF;
                    dma[2].cnt = 0;
                }
            }
        }
    }
    REG_IF = REG_IF;
	REG_IME = 1;
} 
