#ifndef PAUSETEXT_H
#define PAUSETEXT_H

#define PAUSETEXT_WIDTH  (32)
#define PAUSETEXT_HEIGHT (32)
#define pauseTextMapLen (2048)

extern const unsigned short pauseTextMap[1024];

#endif
