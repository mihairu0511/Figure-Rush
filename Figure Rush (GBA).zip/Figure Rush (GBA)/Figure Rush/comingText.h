#ifndef COMINGTEXT_H
#define COMINGTEXT_H

#define COMINGTEXT_WIDTH  (32)
#define COMINGTEXT_HEIGHT (32)
#define comingTextMapLen (2048)

extern const unsigned short comingTextMap[1024];

#endif
