# FIGURE RUSH

## **States**

Start State: 
- Press select → Manual State
- Press A → Stage Selection

Manual State: 
- Press select → Start State

Stage Selection: 
- Press A → Game State

Game State: 
- Press select → Pause State

- When you get to the end of the map, you will be sent to the Win State

Win State: 
- Press Start → Start State
