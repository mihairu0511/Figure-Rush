#ifndef LONGMAP_H
#define LONGMAP_H

#define LONGMAP_WIDTH  (256)
#define LONGMAP_HEIGHT (32)
#define longmapMapLen (16384)

extern const unsigned short longmapMap[8192];

#endif
