// winSound sound made by wav2c

extern const unsigned int winSound_sampleRate;
extern const unsigned int winSound_length;
extern const signed char winSound_data[];
