#ifndef LOSETEXT_H
#define LOSETEXT_H

#define LOSETEXT_WIDTH  (32)
#define LOSETEXT_HEIGHT (32)
#define loseTextMapLen (2048)

extern const unsigned short loseTextMap[1024];

#endif
