// funkytown sound made by wav2c

extern const unsigned int funkytown_sampleRate;
extern const unsigned int funkytown_length;
extern const signed char funkytown_data[];
