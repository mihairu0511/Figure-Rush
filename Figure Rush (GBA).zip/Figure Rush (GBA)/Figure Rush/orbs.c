#include "orbs.h"
#include "gba.h"
#include "mode0.h"
#include "sprites.h"
#include "print.h"
#include "spritesheet.h"
#include "player.h"

void initOrbs() {
    yellowOrb[0].x = 608;
    yellowOrb[0].y = 120;
    yellowOrb[0].width = 18;
    yellowOrb[0].height = 16;
    yellowOrb[0].oamIndex = 1;
    yellowOrb[0].timeUntilNextFrame = 10;
    yellowOrb[0].currentFrame = 0;
    yellowOrb[0].numFrames = 3;

    yellowOrb[1].x = 1784;
    yellowOrb[1].y = 144;
    yellowOrb[1].width = 18;
    yellowOrb[1].height = 16;
    yellowOrb[1].oamIndex = 2;
    yellowOrb[1].timeUntilNextFrame = 10;
    yellowOrb[1].currentFrame = 0;
    yellowOrb[1].numFrames = 3;

    blueOrb[0].x = 2504;
    blueOrb[0].y = 136;
    blueOrb[0].width = 18;
    blueOrb[0].height = 16;
    blueOrb[0].oamIndex = 3;
    blueOrb[0].timeUntilNextFrame = 10;
    blueOrb[0].currentFrame = 0;
    blueOrb[0].numFrames = 3;

    blueOrb[1].x = 2600;
    blueOrb[1].y = 80;
    blueOrb[1].width = 18;
    blueOrb[1].height = 16;
    blueOrb[1].oamIndex = 4;
    blueOrb[1].timeUntilNextFrame = 10;
    blueOrb[1].currentFrame = 0;
    blueOrb[1].numFrames = 3;

    yellowPlatform[0].x = 3632;
    yellowPlatform[0].y = 128;
    yellowPlatform[0].width = 16;
    yellowPlatform[0].height = 16;
    yellowPlatform[0].oamIndex = 5;
    yellowPlatform[0].timeUntilNextFrame = 10;
    yellowPlatform[0].currentFrame = 0;
    yellowPlatform[0].numFrames = 4;

    yellowPlatform[1].x = 3688;
    yellowPlatform[1].y = 128;
    yellowPlatform[1].width = 16;
    yellowPlatform[1].height = 16;
    yellowPlatform[1].oamIndex = 6;
    yellowPlatform[1].timeUntilNextFrame = 10;
    yellowPlatform[1].currentFrame = 0;
    yellowPlatform[1].numFrames = 4;

    yellowPlatform[2].x = 3744;
    yellowPlatform[2].y = 128;
    yellowPlatform[2].width = 16;
    yellowPlatform[2].height = 16;
    yellowPlatform[2].oamIndex = 7;
    yellowPlatform[2].timeUntilNextFrame = 10;
    yellowPlatform[2].currentFrame = 0;
    yellowPlatform[2].numFrames = 4;
}

void animateOrbs() {
    for(int i = 0; i < YELLOW_ORB_COUNT; ++i) {
        --yellowOrb[i].timeUntilNextFrame;
        if (yellowOrb[i].timeUntilNextFrame == 0) {
            yellowOrb[i].currentFrame = (yellowOrb[i].currentFrame + 1) % yellowOrb[i].numFrames;
            yellowOrb[i].timeUntilNextFrame = 10;
        }
    }
    
    for(int i = 0; i < YELLOW_PLATFORM_COUNT; ++i) {
        --yellowPlatform[i].timeUntilNextFrame;
        if (yellowPlatform[i].timeUntilNextFrame == 0) {
            yellowPlatform[i].currentFrame = (yellowPlatform[i].currentFrame + 1) % yellowPlatform[i].numFrames;
            yellowPlatform[i].timeUntilNextFrame = 10;
        }
    }

    for(int i = 0; i < BLUE_ORB_COUNT; ++i) {
        --blueOrb[i].timeUntilNextFrame;
        if (blueOrb[i].timeUntilNextFrame == 0) {
            blueOrb[i].currentFrame = (blueOrb[i].currentFrame + 1) % blueOrb[i].numFrames;
            blueOrb[i].timeUntilNextFrame = 10;
        }
    }
}

void drawOrbs() {

    for(int i = 0; i < YELLOW_ORB_COUNT; ++i) {
        if (collision(yellowOrb[i].x, yellowOrb[i].y, yellowOrb[i].width, yellowOrb[i].height, hOff, vOff, SCREENWIDTH, SCREENHEIGHT)) {
            shadowOAM[yellowOrb[i].oamIndex].attr0 = ATTR0_REGULAR |ATTR0_SQUARE| ATTR0_Y(yellowOrb[i].y - vOff);
            shadowOAM[yellowOrb[i].oamIndex].attr1 = ATTR1_SMALL | ATTR1_X(yellowOrb[i].x - hOff);
            shadowOAM[yellowOrb[i].oamIndex].attr2 = ATTR2_PALROW(0) | (ATTR2_TILEID(1, yellowOrb[i].currentFrame * 2));
        }
    }
    
    for(int i = 0; i < YELLOW_PLATFORM_COUNT; ++i) {
        if (collision(yellowPlatform[i].x, yellowPlatform[i].y, yellowPlatform[i].width, yellowPlatform[i].height, hOff, vOff, SCREENWIDTH, SCREENHEIGHT)) {
            shadowOAM[yellowPlatform[i].oamIndex].attr0 = ATTR0_REGULAR |ATTR0_WIDE| ATTR0_Y(yellowPlatform[i].y - vOff);
            shadowOAM[yellowPlatform[i].oamIndex].attr1 = ATTR1_SMALL | ATTR1_X(yellowPlatform[i].x - hOff);
            shadowOAM[yellowPlatform[i].oamIndex].attr2 = ATTR2_PALROW(0) | (ATTR2_TILEID(5, yellowPlatform[i].currentFrame * 2));
        }
    }

    for(int i = 0; i < BLUE_ORB_COUNT; ++i) {
        if (collision(blueOrb[i].x, blueOrb[i].y, blueOrb[i].width, blueOrb[i].height, hOff, vOff, SCREENWIDTH, SCREENHEIGHT)) {
            shadowOAM[blueOrb[i].oamIndex].attr0 = ATTR0_REGULAR |ATTR0_SQUARE| ATTR0_Y(blueOrb[i].y - vOff);
            shadowOAM[blueOrb[i].oamIndex].attr1 = ATTR1_SMALL | ATTR1_X(blueOrb[i].x - hOff);
            shadowOAM[blueOrb[i].oamIndex].attr2 = ATTR2_PALROW(0) | (ATTR2_TILEID(3, blueOrb[i].currentFrame * 2));
        }
    }
}